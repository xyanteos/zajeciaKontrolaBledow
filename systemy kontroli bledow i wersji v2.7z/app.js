// PAMIETAJ ze wszystkie linijki sa egzekwowane linearnie (w sesnie od gory do dolu.)
const express = require("express");
const app = express();
const morgan = require("morgan");
const productRoutes = require("./api/routes/products");
const bodyParser = require("body-parser");

app.use(morgan("dev"));
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json())
//wszystko co po domena:3000/products
app.use("/products", productRoutes);

// obsluga bledow \/ (wszystko co po domena:3000/)
app.use((req,res,next) =>{
    const error = new Error("Nie znaleziono");
    error.status = 404;
    next(error);//tutaj wywalam error ktory bedzie dopisany do wartosci wejsciowych w nastepnej fukncji
});

app.use((error,req,res,next) =>{
    res.status(error.status || 500).json({
        error:{
            wiadomosc :  error.message
        }
    });
});

module.exports = app;