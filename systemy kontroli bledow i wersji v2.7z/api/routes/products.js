const express = require("express");//importuje express
const router = express.Router();

router.get("/",(req, res, next) =>{
    res.status(200).json({
        wiadomosc: "Lista wszystkich produktów"
    });
});
router.post("/",(req, res, next) =>{
    const produkt = {
        name: req.body.name,
        price: req.body.price
    };
    res.status(200).json({
        wiadomosc: "Dodanie nowego produktu",
        utworzonyProdukt : produkt
    });
});
router.get("/:PrID", (req, res, next) => {
    const id = req.params.PrID;
    res.status(200).json({wiadomosc: "Szczegóły produktu o numerze " + id});
});
router.patch("/:PrID", (req, res, next) => {
    const id = req.params.PrID;
    res.status(200).json({wiadomosc: "Zmiana produktu o numerze " + id});
});

router.delete("/:PrID", (req, res, next) => {
    const id = req.params.PrID;
    res.status(200).json({wiadomosc: "Usunięcie produktu o numerze " + id});
});



module.exports = router; //exportuje router.


// orders do domu 
// get, post
// parametryczny: get, delete